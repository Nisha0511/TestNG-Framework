package ProjectE2E.framework;



public class LoginPage  {
	
	
	
	
		/*
		 * public LoginPage(WebDriver driver) { super(driver); this.driver=driver;
		 * PageFactory.initElements(driver, this);
		 * 
		 * }
		 */
	
//public void initiatBrowser()
/*{
	
		ChromeOptions option = new ChromeOptions();

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver(option);
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
*/
	
	
		/*driver.get("https://www.amazon.in");
	driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();
		
		driver.findElement(By.id("ap_email")).sendKeys("7320996522");
		driver.findElement(By.id("continue")).click();
		driver.findElement(By.id("ap_password")).sendKeys("P1@inDian");
		driver.findElement(By.id("signInSubmit")).click();
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Party dress");
		//driver.findElement(By.id("nav-search-submit-button")).click();
		
		driver.findElement(By.xpath("//div[@class='nav-right']/div/span")).click();
		
		List<WebElement> products=driver.findElements(By.xpath("//span[@class='a-size-base-plus a-color-base a-text-normal']"));
		products.get(0).click();
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.id("add-to-cart-button")).click();
		driver.findElement(By.name("proceedToRetailCheckout")).click();
		//driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).click();
		
		
		 * driver.findElement(By.id(
		 * "address-ui-widgets-countryCode-dropdown-nativeId_155")).click();
		 * driver.findElement(By.name("address-ui-widgets-enterAddressFullName")).
		 * sendKeys("Nisha");
		 * driver.findElement(By.cssSelector("#address-ui-widgets-enterAddressLine1")).
		 * sendKeys("123");
		 * driver.findElement(By.cssSelector("#address-ui-widgets-enterAddressLine2")).
		 * sendKeys("VidyaPati Colony");
		 * driver.findElement(By.cssSelector("#address-ui-widgets-enterAddressCity")).
		 * sendKeys("Madhubani");
		 * driver.findElement(By.id("address-ui-widgets-enterAddressStateOrRegion")).
		 * sendKeys("Bihar");
		 * 
		 * driver.findElement(By.name("address-ui-widgets-enterAddressPostalCode")).
		 * sendKeys("847211");
		 * driver.findElement(By.id("address-ui-widgets-enterAddressPhoneNumber")).
		 * sendKeys("9564413263");
		 * driver.findElement(By.id("address-ui-widgets-use-as-my-default")).click();
		 
		driver.findElement(By.xpath("//input[@data-testid='Address_selectShipToThisAddress']")).click();
		
		 
		
		
		

	}

}*/
	
}

package ProjectE2E.framework;

public class Global {

	//windows-we add backward sslash to use any path
	
	public static String TestDataPath=System.getProperty("user.dir") + "//TestData//TestData.xlsx";
	
	
}
